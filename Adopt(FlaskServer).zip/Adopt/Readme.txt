Essa versão foi feita para rodar um servidor Flask
Sim, você precisa ter o Python e o Flask instalados para rodar o backend (python app.py) 
caso queira que o sistema processe dados, armazene informações, e gere gráficos 
dinamicamente.

Rodar com: pyhon app.py